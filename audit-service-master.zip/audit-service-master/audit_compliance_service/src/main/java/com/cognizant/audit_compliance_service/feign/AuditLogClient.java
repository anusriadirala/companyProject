package com.cognizant.audit_compliance_service.feign;

import com.cognizant.audit_compliance_service.dto.AuditLogDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "AUDIT-LOG-SERVICE")
public interface AuditLogClient {

    @PostMapping("/api/v1/audit-log/add")
    void addLog(@RequestBody AuditLogDTO logDTO);

}